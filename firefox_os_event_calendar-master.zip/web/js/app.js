'use strict'

IDBHandler.init();

all_day_event.init();
save_event.init();
calendar.init();
details.init();
maps.init();
exporter.init();
pager.init();